#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  char debug_mode;
  char file_name[128];
  int unit_size;
  unsigned char mem_buf[10000];
  size_t mem_count;
  char display_mode;
  /*
   .
   .
   Any additional fields you deem necessary
  */
} state;

struct fun_desc {
    char* name;
    void (*fun)(state* s);
};

static char* hex_formats[] = {"%#hhx\n", "%#hx\n", "No such unit", "%#x\n"};
static char* dec_formats[] = {"%#hhd\n", "%#hd\n", "No such unit", "%#d\n"};

void toggleDebugMode(state* s){
    if (s->debug_mode == 1){
        s->debug_mode = 0;
        fprintf(stderr,  "Debug flag now off\n");
    }
    else {
        s->debug_mode = 1;
        fprintf(stderr,  "Debug flag now on\n");;
    }
}
void setFileName(state* s){
    char name[128];
    printf("Input a file name: \n");
    fgets(name, 128, stdin);        
    sscanf(name, "%s", s->file_name);
    FILE * file = fopen(s->file_name, "rb");
    fseek(file, 0, SEEK_END);
    s->mem_count = ftell(file);
    fclose(file);
    if (s->debug_mode == 1){
        fprintf(stderr,  "Debug: file name set to '%s' \n", s->file_name);
    }
}

void setUnitSize(state* s){     
    char un_size[16];
    int un_size_int;
    printf("%s", "Input a Unit size: \n");
    fgets(un_size, 16, stdin);
    sscanf(un_size, "%d", &un_size_int);
    if (un_size_int == 1 || un_size_int == 2 ||un_size_int == 4){
        s->unit_size = un_size_int;
        if (s->debug_mode == 1){
            fprintf(stderr,  "Debug: set size to %d\n", s->unit_size);
        }
    }
    else {
        fprintf(stderr,  "%d is not a valid unit size\n", un_size_int);
    }
}

void loadIntoMemory(state* s){
    char input[128];
    char location[128];
    int length;
    FILE *file;

    if (strcmp(s->file_name, "") == 0){
        fprintf(stderr,  "No file to load in\n");
        return;
    }
    file = fopen(s->file_name, "rb");
    if (file == NULL){
        fprintf(stderr, "Error opening the file %s\n", s->file_name);
        return;
    }
    printf("Please enter location and length\n");
    fgets(input, 128, stdin);
    sscanf(input, "%s %d", location, &length);
    if (s->debug_mode == 1){
            fprintf(stderr,  "Debug: the file name is %s, the location is 0x%s, the length is %d\n", s->file_name, location, length);
        }
    int location_in_dec = strtol(location, NULL, 16);
    fseek(file, location_in_dec, SEEK_SET);        // The SEEK_SET constant specifies that the offset is from the beginning of the file.
    size_t read_bytes = fread(s->mem_buf, 1, length*s->unit_size, file);
    if (read_bytes != length*s->unit_size){
        printf("Error could not read %d bytes from file %s\n", length, s->file_name);
        fclose(file);
        return;
    }

    fclose(file);
    printf("Loaded %d units into memory\n", length);
}

// void loadIntoMemory(state* s){
//   if (strcmp(s->file_name,"") == 0){
//     fprintf(stderr, "Error: No file name\n");
//   } else {
//     if (fopen(s->file_name,"r") == NULL){
//       fprintf(stderr, "Error: couldn't open file\n");
//     } else {
//       int location;
//       int length;
//       printf("%s", "Enter location (in hexadecimal): ");
//       fgets("%x\n", location, stdin);
//       printf("%s", "Enter length (in decimal): ");
//       sscanf("%d\n", length);
//       if (fseek(s->file_name, length, location) != 0){
//         fread(s->mem_buf, s->unit_size, length, s->file_name);
//         printf("Loaded %d units into memory\n", length);
//       }
//         fclose(s->file_name);
//     }
//   }
//}

void toggleDisplayMode(state* s){
    if (s->display_mode == 1){
        s->display_mode = 0;
        fprintf(stderr,  "Display flag now off, decimal representation\n");
    }
    else {
        s->display_mode = 1;
        fprintf(stderr,  "Display flag now on, hexadecimal representation\n");;
    }
}
void memoryDisplay(state* s){   //?????????????
    unsigned char* buf = s->mem_buf;
    //unsigned char unit_buf[s->unit_size];
    int u;
    int addr_int;
    int lenght;
    char addr[128];
    char input[128];
    // FILE *file;

    printf("%s", "Enter address and length:\n");
    fgets(input, 128, stdin);
    sscanf(input, "%hhx %d", addr, &u);

    addr_int = strtol(addr, NULL, 16);
    lenght = u * s->unit_size;

    if (addr_int + lenght > sizeof(s->mem_buf)){
        fprintf(stderr,  "Error too much to read\n");
    }

    // if (strcmp(s->file_name, "") == 0){
    //         fprintf(stderr,  "No file to load in\n");
    //         return;
    //     }
    
    // file = fopen(s->file_name, "rb");
    //         if (file == NULL){
    //             fprintf(stderr, "Error opening the file\n");
    //             return;
    //         }

    if (s->debug_mode == 1){
            printf("Debug: The address is %s, the length is %d\n", addr, u);
    }

    for (int i = 0; i < lenght; i++){
        if (s->display_mode == 1){
            printf(hex_formats[s->unit_size - 1], buf[addr_int + i]);
        }
        else{
            printf(dec_formats[s->unit_size - 1], buf[addr_int + i]);
        }
    }

    //fclose(file);

}//??????????

void saveIntoFile(state* s){
    char input[128];
    char source_address[128];
    char target_location[128];
    int length;
    int source_address_int;
    int target_location_int;

    printf("Enter <source-address> <target-location> <length>:\n");
    fgets(input, 128, stdin);
    sscanf(input, "%s %s %d", source_address, target_location, &length);

    source_address_int = strtol(source_address, NULL, 16);
    target_location_int = strtol(target_location, NULL, 16);

    if (s->debug_mode == 1){
            printf("Debug: The address is %hhx, the location is %hhx\n", source_address, target_location);
    }

    // if (source_address_int > sizeof(s->mem_buf) + s->mem_count){
    //         printf("Invalid source address\n");
    //         return;
    //     }

    if (target_location_int > s->mem_count){
        printf("Invalid target length\n");
        return;
    }
    
    FILE *file = fopen(s->file_name, "wb");
    if (file == NULL) {
        printf("Error opening file: %s\n", s->file_name);
        return;
    }

    fseek(file, target_location_int, SEEK_SET);
    unsigned char * val = (unsigned char *) s->mem_buf + source_address_int;
    fwrite(&val, s->unit_size, length, file);

    // size_t bytes_written = fwrite(s->mem_buf + source_address_int, s->unit_size, length, file);
    // if (bytes_written != length) {
    //     printf("Error writing file\n");
    //     fclose(file);
    //     return;
    // }

    fclose(file);
}

void memoryModify(state* s){
    char input[128];
    char location[128];
    char val[128];

    printf("Enter <location> <val>:\n");
    fgets(input, 128, stdin);
    sscanf(input, "%s %s",  location, val);

    if (s->debug_mode == 1){
        printf("The location is 0x%s, and the val is 0x%s", location, val);
    }

    int location_int = strtol(location, NULL, 16);
    
    if (location_int >= sizeof(s->mem_buf)){
        printf("Error location is outside of memory buffer size\n");
    }

    for (int i = 0; i < sizeof(val); i++){
        s->mem_buf[location_int + i] = val[i];
    }
}

void quit(state* s){
    if (s->debug_mode){
        printf("quitting\n");
    }
    free(s);
    exit(0);
}

struct fun_desc menu[] = {{"0-Toggle Debug Mode", toggleDebugMode}, {"1-Set File Name", setFileName}, 
                            {"2-Set Unit Size", setUnitSize}, {"3-Load Into Memory", loadIntoMemory}, 
                            {"4-Toggle Display Mode", toggleDisplayMode}, {"5-Memory Display", memoryDisplay}, 
                            {"6-Save Into File", saveIntoFile}, {"7-Memory Modify", memoryModify}, {"8-Quit", quit}, {NULL,NULL}};

int main(int argc, char **argv){
    int menu_size = sizeof(menu)/sizeof(menu[0])-1; // Exclude the NULL
    char buffer[menu_size];
    char choice;
    state * s = malloc(sizeof(state));
    s->debug_mode = 0;
    s->display_mode = 0;
    s->unit_size = 1;
    while(1){
        if (s->debug_mode == 1){
            fprintf(stderr, "Unit size: %d\n", s->unit_size);
            fprintf(stderr, "File name: %s\n", s->file_name);
            fprintf(stderr, "Memory count: %d\n", s->mem_count);
        }
        printf( "%s", "choose action:\n");
        for(int i = 0; i < menu_size; i++){
            printf("%s\n", menu[i].name);
        }
        fgets(buffer, menu_size, stdin);  
        sscanf(buffer, "%c",&choice);
        if (choice == '\0'){
            break;
        }
        int choice_int = choice-48;
        if ((choice_int >= 0) & (choice_int < (menu_size))){
            menu[choice_int].fun(s);
        } else {
            printf("%s\n", "Not within bounds");
            break;
        }
    }
    return 0;
}