#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  char debug_mode;
  char file_name[128];
  int unit_size;
  unsigned char mem_buf[10000];
  size_t mem_count;
} state;

void toggle_debug_mode(state* s) {
  s->debug_mode = !s->debug_mode;
  if (s->debug_mode) {
    printf("Debug flag now on\n");
  } else {
    printf("Debug flag now off\n");
  }
}

void set_file_name(state* s) {
  char buf[128];
  printf("Please enter a file name: ");
  fgets(buf, sizeof(buf), stdin);
  buf[strlen(buf) - 1] = '\0';
  strcpy(s->file_name, buf);
  if (s->debug_mode) {
    printf("Debug: file name set to '%s'\n", s->file_name);
  }
}

void set_unit_size(state* s) {
  int value;
  printf("Please enter a unit size (1, 2, or 4): ");
  scanf("%d", &value);
  if (value == 1 || value == 2 || value == 4) {
    s->unit_size = value;
    if (s->debug_mode) {
      printf("Debug: set size to %d\n", s->unit_size);
    }
  } else {
    printf("Invalid unit size\n");
  }
}

void quit(state* s) {
  printf("Quitting\n");
  exit(0);
}

void load_into_memory(state* s) {
  if (s->file_name[0] == '\0') {
    printf("No file name set\n");
    return;
  }

  FILE* file = fopen(s->file_name, "rb");
  if (file == NULL) {
    printf("Error opening file '%s'\n", s->file_name);
    return;
  }

  unsigned char* buf = s->mem_buf;
  size_t buf_size = sizeof(s->mem_buf);
  size_t bytes_read;
  int location, length;

  printf("Please enter a location and length: ");
  scanf("%x %d", &location, &length);

  bytes_read = fread(buf, 1, length * s->unit_size, file);
  if (bytes_read != length * s->unit_size) {
    printf("Error reading file\n");
    fclose(file);
    return;
  }

  fclose(file);

  printf("Loaded %d units into memory\n", length);
}

void toggle_display_mode(state* s) {
  s->debug_mode = !s->debug_mode;
  if (s->debug_mode) {
    printf("Display flag now on, hexadecimal representation\n");
  } else {
    printf("Display flag now off, decimal representation\n");
  }
}

void memory_display(state* s) {
  unsigned char* buf = s->mem_buf;
  size_t buf_size = sizeof(s->mem_buf);
  size_t addr, length;

  printf("Please enter an address and length: ");
  scanf("%x %d", &addr, &length);

  if (addr == 0) {
    addr = buf_size;
  }

  if (addr + length > buf_size) {
    length = buf_size - addr;
  }

  if (s->debug_mode) {
    for (size_t i = 0; i < length; i++) {
      printf("%02x ", buf[addr + i]);
    }
    printf("\n");
  } else {
    for (size_t i = 0; i < length; i++) {
    printf("%d ", buf[addr + i]);
  }
  printf("\n");
}
}

void save_into_file(state* s) {
  if (s->file_name[0] == '\0') {
    printf("No file name set\n");
    return;
  }

  FILE* file = fopen(s->file_name, "wb");
  if (file == NULL) {
    printf("Error opening file '%s'\n", s->file_name);
    return;
  }

unsigned char* buf = s->mem_buf;
  size_t buf_size = sizeof(s->mem_buf);
  size_t bytes_written;
  int location, length;

  printf("Please enter a location and length: ");
  scanf("%x %d", &location, &length);

  bytes_written = fwrite(buf + location, 1, length * s->unit_size, file);
  if (bytes_written != length * s->unit_size) {
    printf("Error writing file\n");
    fclose(file);
    return;
  }

  fclose(file);

  printf("Saved %d units into file\n", length);
}


void memory_modify(state* s) {
  unsigned char* buf = s->mem_buf;
  size_t buf_size = sizeof(s->mem_buf);
  size_t addr, length;
  int value;

  printf("Please enter an address, length, and value: ");
  scanf("%x %d %d", &addr, &length, &value);

  if (addr == 0) {
    addr = buf_size;
  }

  if (addr + length > buf_size) {
    length = buf_size - addr;
  }

  for (size_t i = 0; i < length; i++) {
    buf[addr + i] = value;
  }

  printf("Modified %d units in memory\n", length);
}

void main() {
  state s;
  s.debug_mode = 0;
  s.file_name[0] = '\0';
  s.unit_size = 1;
  s.mem_count = 0;

  while (1) {
    printf("Choose action:\n");
    printf("0-Toggle Debug Mode\n");
    printf("1-Set File Name\n");
    printf("2-Set Unit Size\n");
    printf("3-Load Into Memory\n");
    printf("4-Toggle Display Mode\n");
    printf("5-Memory Display\n");
    printf("6-Save Into File\n");
    printf("7-Memory Modify\n");
    printf("8-Quit\n");

    int choice;
    scanf("%d", &choice);

    switch (choice) {
    case 0:
      toggle_debug_mode(&s);
      break;
    case 1:
      set_file_name(&s);
      break;
    case 2:
      set_unit_size(&s);
      break;
    case 3:
      load_into_memory(&s);
      break;
    case 4:
      toggle_display_mode(&s);
      break;
    case 5:
      memory_display(&s);
      break;
    case 6:
      save_into_file(&s);
      break;
      case 7:
      memory_modify(&s);
      break;
    case 8:
      quit(&s);
      break;
    default:
      printf("Invalid choice\n");
    }
  }
}
