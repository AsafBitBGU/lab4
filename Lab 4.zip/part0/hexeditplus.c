#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  char debug_mode;
  char file_name[128];
  int unit_size;
  unsigned char mem_buf[10000];
  size_t mem_count;
  /*
   .
   .
   Any additional fields you deem necessary
  */
} state;

struct fun_desc {
    char* name;
    void (*fun)(state* s);
};


void toggelDebugMode(state* s){
    if (s->debug_mode == 1){
        s->debug_mode = 0;
        fprintf(stderr,  "Debug flag now off\n");
    }
    else {
        s->debug_mode = 1;
        fprintf(stderr,  "Debug flag now on\n");;
    }
}
void setFileName(state* s){
    printf("%s", "Input a file name: \n");
    fgets(s->file_name, 100, stdin);
    if (s->debug_mode == 1){
        fprintf(stderr,  "Debug: file name set to '%s' \n", s->file_name);
    }
}
void setUnitSize(state* s){
    char un_size;
    printf("%s", "Input a Unit size: \n");
    un_size = getchar();
    if (un_size == '1' || un_size == '2' || un_size == '4'){
        s->unit_size = (un_size -48);
        if (s->debug_mode == 1){
            fprintf(stderr,  "Debug: set size to %d\n", s->unit_size);
        }
    }
    else {
        fprintf(stderr,  "%s is not a valid unit size\n", s->file_name);
    }
}
void loadIntoMemory(state* s){

}
void toggelDispleyMode(state* s){

}
void memoryDisplay(state* s){

}
void saveIntoFile(state* s){

}
void memoryModify(state* s){

}
void quit(state* s){
    if (s->debug_mode == 1){
        fprintf(stderr,  "Debug: quitting\n");
    }
    exit(0);
}
struct fun_desc menu[] = {{"0-Toggel Debug Mode", toggelDebugMode}, {"1-Set File Name", setFileName}, {"2-Set Unit Size", setUnitSize}, {"3-Load Into Memory", loadIntoMemory}, {"4-Toggel Displey Mode", toggelDispleyMode}, {"5-Memory Display", memoryDisplay}, {"6-Save Into File", saveIntoFile}, {"7-Memory Modify", }, {"8-Quit", quit}, {NULL,NULL}};

int main(int argc, char **argv){
    int menu_size = sizeof(menu)/sizeof(menu[0])-1; // Exclude the NULL
    char buffer[menu_size];
    char choice;
    state s;
    s.debug_mode = 0;
    while(1){
        if (s.debug_mode == 1){
            fprintf(stderr, "Unit size: %d\n", s.unit_size);
            fprintf(stderr, "File name: %s\n", s.file_name);
            fprintf(stderr, "Memory count: %d\n", s.mem_count);
        }
        printf( "%s", "choose action:\n");
        for(int i = 0; i < menu_size; i++){
            printf("%s\n", menu[i].name);
        }
        fgets(buffer, menu_size, stdin);  
        sscanf(buffer, "%c",&choice);
        if (choice == '\0'){
            break;
        }

        if ((choice >= '0') & (choice < (menu_size + '0'))){
            menu[choice-48].fun(&s);
        } else {
            printf("%s\n", "Not within bounds");
            break;
        }
    }
    return 0;
}